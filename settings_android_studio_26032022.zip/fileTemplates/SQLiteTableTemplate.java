#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;


public class ${ClassName} {
    public static final String TAG =  ${ClassName}.class.getSimpleName();

    private final Context context;

    public static final String TABLE_NAME = "${TableName}";


    private ${DatabaseHelperName} mDatabase;

    private static ${ClassName} instance;

    public static ${ClassName} getInstance(Context context){
        if(instance == null)
            instance = new ${ClassName}(context);
        return instance;
    }

    private ${ClassName}(Context context) {
        this.context = context;
        this.mDatabase = ${DatabaseHelperName}.getInstance(context);
        if(!mDatabase.checkTableExist(TABLE_NAME))
            createTable();
    }

    private void createTable(){
        final String create_table = String.format("CREATE TABLE %s (  )", TABLE_NAME);
        mDatabase.getWritableDatabase().execSQL(create_table);
    }

    public void addOrUpdate(${Object} item) {
        
    }

    /**
     * Add 
     * @return status
     */
    public void add(${Object} item){
        if(!checkItemExistByID(item.getId())){
            ContentValues values = new ContentValues();
            
            SQLiteDatabase db = mDatabase.getWritableDatabase();
            db.insert(TABLE_NAME, null, values);
        }
    }


    /**
     * Update 
     * @return status
     */
    public void update(${Object} item){
        if(checkItemExistByID(item.getId())){
            ContentValues values = new ContentValues();
            SQLiteDatabase db = mDatabase.getWritableDatabase();
            db.update(TABLE_NAME,
                    values,
                    KEY_ID + " = ?",
                    new String[] { String.valueOf(city.getId()) });
    
        }
    }


    /**
     * Delete 
     * @return delete status
     */
    public boolean delete(String id){
        SQLiteDatabase db = mDatabase.getWritableDatabase();
        return db.delete(TABLE_NAME, KEY_ID + " = ? AND " + KEY_ID + " = ?", new String[]{String.valueOf(id)}) > 0;
    }

    /**
     * Delete all data
     */
    public void deleteAll(){
        try{
            SQLiteDatabase db = mDatabase.getWritableDatabase();
            db.execSQL("DELETE FROM "+ TABLE_NAME);
        }catch (Exception e){
            Log.d(TAG,e.toString());
        }
    }

    /**
     * Check if an item exists
     * @return exist or not exist
     */
    public boolean checkItemExistByID(String id){
        SQLiteDatabase db = mDatabase.getReadableDatabase();
        String query = String.format("SELECT %s FROM %s WHERE %s = '%s' ", KEY_ID, TABLE_NAME, KEY_ID, id);
        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            cursor.close();
            return true;
        } else {
            cursor.close();
            return false;
        }
    }


    /**
     * 
     * @param id 
     * @return object
     */
    public ${Object} getItemByID(String id){
        String query = String.format("SELECT * FROM %s WHERE %s = '%s' ", KEY_ID, TABLE_NAME, KEY_ID, id);
        SQLiteDatabase db = mDatabase.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        if (cursor != null){
            if(cursor.moveToFirst()){
                ${Object} result = convertCursorToObject(cursor);
                cursor.close();
                return result;
            }
        }
        return null;
    }



    /**
     * 
     * @return ArrayList<Object>
     */
    public ArrayList<${Object}> getListItem(){
        ArrayList<${Object}> listItem = new ArrayList<>();

        String query = String.format("");

        SQLiteDatabase db = mDatabase.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        if (cursor!=null){
            if(cursor.moveToFirst()){
                while(!cursor.isAfterLast()){
                   
                    listItem.add(convertCursorToObject(cursor));
                    cursor.moveToNext();
                }
            }
            cursor.close();
        }
        return listItem;
    }
    
        private ${Object} convertCursorToObject(Cursor cursor){
            return new ${Object}(cursor.getString(cursor.getColumnIndex(COL_BOY_NAME)),
                    cursor.getString(cursor.getColumnIndex(COL_GIRL_NAME)),
                    cursor.getLong(cursor.getColumnIndex(COL_DATE_START)),
                    cursor.getString(cursor.getColumnIndex(COL_AVATAR_BOY)),
                    cursor.getString(cursor.getColumnIndex(COL_AVATAR_GIRL)));
    }

}
