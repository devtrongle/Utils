package vn.james.sharelocation.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;



/*******************************************************************************
 * Date created: 2021/1/27
 * Last updated:  2021/1/27
 * Auth: James Ryan
 ******************************************************************************/

public class ConfirmDialog {
    public static final String TAG = ConfirmDialog.class.getSimpleName();

    private final Dialog dialog;
    private final Context context;

    private IAccept cbButtonAccept;
    private ICancel cbButtonCancel;

    private boolean mCancelable;

    private boolean isShowButtonCancel;
    private boolean isShowButtonAccept;

    private boolean isBuild;

    private ICallbackMyDialog mCallback;

    private String title;
    private String message;
    private String textCancel;
    private String textAccept;

    private ConfirmDialog(@NonNull Context context){
        this.context = context;
        this.dialog = new Dialog(context);
        this.isBuild = false;
        this.mCancelable = false;
        this.isShowButtonAccept = true;
        this.isShowButtonCancel = true;
    }

    public static ConfirmDialog from(@NonNull Context context){
        return new ConfirmDialog(context);
    }

    private void dismissDialog(){
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                if(mCallback != null) {
                    mCallback.onDismissDialog();
                }
            }
        });

        if(dialog.isShowing())
            dialog.dismiss();
    }

    public ConfirmDialog setOnCallbackDialog(ICallbackMyDialog mCallback){
        this.mCallback = mCallback;
        return this;
    }

    public Dialog getDialog(){
        return this.dialog;
    }

    /**
     * Sets whether this dialog is cancelable with the
     * {@link KeyEvent#KEYCODE_BACK BACK} key.
     */
    public ConfirmDialog setCancelable(boolean flag) {
        mCancelable = flag;
        return this;
    }


    public ConfirmDialog setShowButtonCancel(boolean showButtonCancel) {
        isShowButtonCancel = showButtonCancel;
        return this;
    }

    public ConfirmDialog setShowButtonAccept(boolean showButtonAccept) {
        isShowButtonAccept = showButtonAccept;
        return this;
    }

    public ConfirmDialog setTitle(String title) {
        this.title = title;
        return this;
    }

    public ConfirmDialog setMessage(String message) {
        this.message = message;
        return this;
    }

    public ConfirmDialog setButtonCancel(@Nullable String text, @Nullable ICancel cbButtonCancel) {
        this.textCancel = text;
        this.cbButtonCancel = cbButtonCancel;
        return this;
    }

    public ConfirmDialog setButtonAccept(@Nullable String text, @Nullable IAccept cbButtonAccept) {
        this.textAccept = text;
        this.cbButtonAccept = cbButtonAccept;
        return this;
    }

    public ConfirmDialog setTextCancel(String textCancel) {
        this.textCancel = textCancel;
        return this;
    }

    public ConfirmDialog setTextAccept(String textAccept) {
        this.textAccept = textAccept;
        return this;
    }

    public ConfirmDialog build(){
        isBuild = true;
        dialog.setCancelable(mCancelable);
        DialogConfirmBinding mView = DialogConfirmBinding.inflate(LayoutInflater.from(context));
        dialog.setContentView(mView.getRoot());

        if(title != null){
            mView.tvTitle.setText(title);
        }

        if(message != null){
            mView.tvContent.setText(message);
        }

        if(textCancel != null){
            mView.btnCancel.setText(textCancel);
        }

        if(textAccept != null){
            mView.btnAccept.setText(textAccept);
        }

        mView.btnCancel.setVisibility(isShowButtonCancel ? View.VISIBLE : View.GONE);
        mView.btnAccept.setVisibility(isShowButtonAccept ? View.VISIBLE : View.GONE);

        //Set action
        mView.btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(cbButtonCancel != null)
                    cbButtonCancel.onClickButtonCancel(dialog);

                dismissDialog();
            }
        });

        mView.btnAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(cbButtonAccept != null)
                    cbButtonAccept.onClickButtonAccept(dialog);

                dismissDialog();
            }
        });

        mView.iBtnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(cbButtonCancel != null)
                    cbButtonCancel.onClickButtonCancel(dialog);

                dismissDialog();
            }
        });

        Window window = dialog.getWindow();
        if(window != null){
            window.setBackgroundDrawableResource(android.R.color.transparent);
        }

        return this;
    }


    public void show(){
        if(!isBuild){
           build();
        }
        dialog.show();
    }


    public interface ICallbackMyDialog {
        void onDismissDialog();
        void onDialogShowing();
    }


    public interface IAccept{
        void onClickButtonAccept(Dialog dialog);
    }

    public interface ICancel{
        void onClickButtonCancel(Dialog dialog);
    }
}

/*
<?xml version="1.0" encoding="utf-8"?><!--
  ~ Date created: 2020/10/20
  ~ Last updated:  2020/10/20
  ~ Name of project: AloLoader
  ~ Description: dialog_confirm.xml
  ~ Auth: James Ryan
  -->

<androidx.cardview.widget.CardView xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:layout_margin="5dp"
    app:cardCornerRadius="5dp">

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:orientation="vertical"
        android:paddingStart="15dp"
        android:paddingEnd="15dp"
        android:paddingBottom="15dp">

        <RelativeLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content">

            <TextView
                android:id="@+id/tvTitle"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:layout_alignParentStart="true"
                android:layout_centerHorizontal="true"
                android:layout_centerVertical="true"
                android:text="@string/app_name"
                android:textColor="@color/twitter_black"
                android:textSize="18sp"
                android:textStyle="bold" />

            <ImageButton
                android:id="@+id/iBtnClose"
                android:layout_width="40dp"
                android:layout_height="40dp"
                android:layout_alignParentEnd="true"
                android:layout_centerVertical="true"
                android:layout_margin="3dp"
                android:background="@drawable/bg_transparent"
                android:src="@drawable/ic_close" />

        </RelativeLayout>

        <View
            android:layout_width="match_parent"
            android:layout_height="1dp"
            android:background="@color/colorLine" />

        <TextView
            android:id="@+id/tvContent"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginStart="10dp"
            android:layout_marginTop="10dp"
            android:layout_marginEnd="10dp"
            android:layout_marginBottom="20dp"
            android:text=""
            android:textColor="@color/twitter_black"
            android:textSize="15sp" />

        <LinearLayout
            android:id="@+id/llBottomControl"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:gravity="end"
            android:orientation="horizontal"
            android:visibility="visible">

            <androidx.appcompat.widget.AppCompatButton
                android:layout_marginBottom="3dp"
                android:id="@+id/btnCancel"
                android:textSize="15sp"
                android:layout_width="wrap_content"
                android:layout_height="40dp"
                android:background="@drawable/bg_transparent"
                android:paddingStart="10dp"
                android:paddingEnd="10dp"
                android:text="Cancel"
                android:textAllCaps="false"
                android:textColor="@color/red"
                android:textStyle="bold" />

            <androidx.appcompat.widget.AppCompatButton
                android:layout_marginBottom="3dp"
                android:textSize="15sp"
                android:id="@+id/btnAccept"
                android:layout_width="wrap_content"
                android:layout_height="40dp"
                android:background="@drawable/bg_transparent"
                android:paddingStart="10dp"
                android:paddingEnd="10dp"
                android:text="Accept"
                android:textAllCaps="false"
                android:textColor="@color/blue"
                android:textStyle="bold" />

        </LinearLayout>

    </LinearLayout>

</androidx.cardview.widget.CardView>



<?xml version="1.0" encoding="utf-8"?>
<!--
  ~ Date created: 2020/10/15
  ~ Last updated:  2020/10/15
  ~ Name of project: 
  ~ Description: bg_transparent.xml
  ~ Auth: James Ryan
  -->

<selector xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:state_focused="true">
        <selector>
            <item android:state_pressed="false">
                <shape>
                    <solid android:color="#A6D1D1D1"/>
                    <corners android:radius="5dp"/>
                </shape>
            </item>

            <item android:state_pressed="true">
                <shape>
                    <solid android:color="#A6E1E1E1"/>
                    <corners android:radius="5dp"/>
                </shape>
            </item>
        </selector>
    </item>

    <item android:state_focused="false">
        <selector>
            <item android:state_pressed="false">
                <shape>
                    <solid android:color="#00000000"/>
                    <corners android:radius="5dp"/>
                </shape>
            </item>

            <item android:state_pressed="true">
                <shape>
                    <solid android:color="#A6E1E1E1"/>
                    <corners android:radius="5dp"/>
                </shape>
            </item>
        </selector>
    </item>
</selector>

*/