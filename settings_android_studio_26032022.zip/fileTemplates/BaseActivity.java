#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public abstract class BaseActivity extends AppCompatActivity {

   
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(initLayout());
        initVariables();
        main(savedInstanceState);
        initAction();
    }


    /**
     * Initialize the root layout
     * @return root view
     */
    protected abstract View initLayout();

    /**
     * Variable initialization
     */
    protected abstract void initVariables();

    /**
     * The main function contains the functions of the application
     * @param savedInstanceState if the activity is being re-initialized after
     *     previously being shut down then this Bundle contains the data it most
     *     recently supplied in {@link #onSaveInstanceState}.
     *     <b><i>Note: Otherwise it is null.</i></b>
     */
    protected abstract void main(@Nullable Bundle savedInstanceState);

    /**
     * Contains key press or interactive functions
     */
    protected abstract void initAction();
    
    /**
     * Start service nếu service đang stop
     * @param serviceClass service class
     */
    public void startService(Class<?> serviceClass){
        if(!isMyServiceRunning(serviceClass)){
            startService(new Intent(this,serviceClass));
        }
    }

    /**
     * Stop service nếu service đang start
     * @param serviceClass service class
     */
    public void stopService(Class<?> serviceClass){
        if(isMyServiceRunning(serviceClass)){
            stopService(new Intent(this,serviceClass));
        }
    }

    /**
     * Kiểm tra service có đang hoạt động hay không
     * @param serviceClass service class
     * @return true là đang hoạt động
     */
    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Cài đặt màu cho text trên status bar
     * @param isResetDefault nếu false set màu đen cho text ngược lại reset lại mặc định trong style.xml
     */
    public void setBlackTextColorStatusBar(boolean isResetDefault){
        //Cài đặt màu đen cho chữ trên status bar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if(isResetDefault){
                getWindow().getDecorView().setSystemUiVisibility(0);
            }else{
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            }
        }
    }

    /**
     * init toolbar
     * @param toolbar toolbar view
     */
    public void initToolbar(Toolbar toolbar){
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    /**
     * init toolbar
     * @param toolbar toolbar view
     * @param resId navigation icon
     */
    public void initToolbar(Toolbar toolbar, @DrawableRes int resId){
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        toolbar.setNavigationIcon(resId);
        toolbar.setNavigationOnClickListener(v -> finish());
    }
    
    
    /**
     * Send email
     * @param emails list of email
     * @param title title email
     * @param body content
     */
    public void sendEmail(@NonNull String[] emails, @Nullable String title, @Nullable String body){
        final Intent iEmail = new Intent(android.content.Intent.ACTION_SEND);
        iEmail.setType("message/rfc822");
        iEmail.putExtra(android.content.Intent.EXTRA_EMAIL, emails);

        if(title != null){
            iEmail.putExtra(Intent.EXTRA_SUBJECT, title);
        }
        if(body != null){
            iEmail.putExtra(Intent.EXTRA_TEXT, body);
        }

        try {
            startActivity(Intent.createChooser(iEmail, "Send mail by));
        } catch (android.content.ActivityNotFoundException ex) {
            Log.e("BaseActivity", "[sendEmail --> " + ex.getMessage());
            Toast.makeText(this, "Could not find \"Email\" application!", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Open a browser and go to the link
     * @param url URL to go to
     */
    public void openBrowser(@NonNull String url){
        Intent iBrowser = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(iBrowser);
    }

    /**
     * Open the google map app and get directions to the location by latitude longitude
     * @param latitude Latitude destination
     * @param longitude Longitude destination
     */
    @SuppressLint("QueryPermissionsNeeded")
    public void openMapDirections(double latitude, double longitude){
        Uri gmmIntentUri = Uri.parse(String.format("google.navigation:q=%s,%s", latitude, longitude));
        Intent iMap = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        iMap.setPackage("com.google.android.apps.maps");
        if (iMap.resolveActivity(getPackageManager()) != null) {
            startActivity(iMap);
        }else{
            Toast.makeText(this, "Could not find \"Google Map\" application!", Toast.LENGTH_SHORT).show();
        }
    }
  
}
